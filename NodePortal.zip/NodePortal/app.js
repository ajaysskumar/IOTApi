'use strict';
var express = require('express');
var app = express();
var bookRouter = express.Router();

var port = process.env.PORT || 5000;

app.listen(port, function (err) {
    console.log('Running at port ' + port);
});

app.use(express.static('public'));
app.set('views', './src/views');

app.set('view engine', 'ejs');

bookRouter.route('/')
    .get(function (req, res) {
        res.send('Hello Books');
    });

bookRouter.route('/Single')
    .get(function (req, res) {
        res.send('Hello Single Book');
    });

app.use('/Books', bookRouter);

app.get('/', function (req, res) {
    res.render('index', {
        title: 'Hello from render',
        nav: [{
                Link: '/Authors',
                Text: 'Authors'
            },
            {
                Link: '/Books',
                Text: 'Books'
            }
        ]
    });
});